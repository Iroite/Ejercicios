---
title: "Parque Nacional das Illas Atlánticas"
date: "2025-04-22"
summary: "Aquí está a mellor praia do mundo. E non o dicimos nós, dío o xornal The Guardian. É a praia de Rodas nas Illas Cíes."
image: "/images/illas_atlanticas.png"
image-post: "/images/illas_atlanticas_post.png"
---


Aquí está a mellor praia do mundo. E non o dicimos nós, dío o xornal The Guardian. É a **praia de Rodas nas Illas Cíes**. Augas cristalinas e tranquilas, area fina e dourada, unha suxestiva forma de media lúa e, protexendo a praia, un bosque de piñeiros que invitan á sesta.

Si en el pasado las Cíes fueron refugio de piratas, ahora están deshabitadas y abiertas al público sólo en verano. Así se conservan como un paraíso natural, sin prisas, sin tráfico. Sólo el rumor de las olas y el viento. Pero si echas de menos el ruido, sube al Faro. Las vistas son impresionantes y podrás disfrutar de un espectáculo único: el griterío de miles de gaviotas (quizá la mayor colonia de Europa) en los acantilados... volando a tus pies.
