---
title: "Praia das Catedrais"
date: "2025-04-22"
summary: "A praia das Catedrais, un monumento natural cunha dimensión sobrenatural."
image: "/images/ribeira_sacra.png"
image-post: "/images/ribeira_sacra_post.png"
---


En Galicia, cando se xunta a potencia do mar e a paciencia do tempo o resultado é unha obra de arte... a **praia das Catedrais**, un monumento natural cunha dimensión sobrenatural. Só hai que esperar á marea baixa, descalzarse, botar a andar... e un xa se sente na gloria.

Nada como desfrutar da vista dos arcobotantes de 30 m de altura, descubrir insólitas perspectivas de arcos dentro doutros arcos. Ou simplemente, deixarse levar polos corredores de area entre muros de lousa, como nunha impoñente e caprichosa nave central. E sempre, os pés na area e a cabeza no ceo.  Estamos na catedral do mar.

O chanzo que forma a denominada rasa cantábrica acada aquí **categoría de monumento xeolóxico**. O mar esculpiu nos cantís todo un repertorio arquitectónico de arcos, columnas e bóvedas que levaron a bautizar turisticamente o espazo entre os areais de Augasantas e Carricelas como praia das Catedrais.
