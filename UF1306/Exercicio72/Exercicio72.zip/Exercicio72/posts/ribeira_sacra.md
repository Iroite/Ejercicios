---
title: "Ribeira Sacra e Canón do Sil"
date: "2025-04-22"
summary: "Percorre en catamarán os impresionantes Canóns do Sil e do Miño, intérnate noutro mundo."
image: "/images/ribeira_sacra.png"
image-post: "/images/ribeira_sacra_post.png"
---


Percorre en catamarán os impresionantes **Canóns do Sil e do Miño**, intérnate noutro mundo. Paraxes impoñentes con fermosos mosteiros que durante séculos, afastados do mundanal ruído e ao amparo do clima benigno destas terras, dedicaron o seu tempo e a súa sabedoría a honrar a Deus e aos homes estudando os segredos da vide.

Falamos de deuses, de homes, de viños... Falamos do encontro das beiras do Sil e do Miño, de canóns de 500 m de profundidade, de diminutos viñedos en escarpadas ladeiras que requiren un esforzo heroico. Algo único que só podes ver aquí.

É esta a Ribeira Sacra, o berce do lendario “Amandi”, un viño tan apreciado polos romanos que o consideraban o verdadeiro **“ouro do Sil”**. Un viño que séculos máis tarde os monxes beneditinos elaborarían en exclusiva para as adegas dos máis refinados papas.
