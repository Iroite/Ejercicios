---
title: "Catedral y Centro Histórico de Santiago"
date: "2025-04-22"
summary: "Contén o alento. O Botafumeiro, a 70 km por hora, voa sobre ti. É maxia na catedral de Santiago de Compostela."
image: "/images/santiago_compostela.png"
image-post: "/images/santiago_compostela_post.png"
---


Contén o alento. O Botafumeiro, a 70 km por hora, voa sobre ti. É maxia na **catedral de Santiago de Compostela**. Unha catedral que xa cumpriu 800 anos e consérvase espléndida, con renovados atractivos. Por exemplo, unha visita guiada polos seus tellados, descubrindo recunchos secretos e novas perspectivas, como admirar desde as alturas a fermosa **praza da Quintana**.

E aos teus pés, o casco histórico. Coas súas igrexas e conventos de clausura, as súas tendas de ourivaría en prata e acibeche, os seus lendarios cafés e casas de comidas, as súas prazas como Obradoiro, Praterías, Cervantes, Toural... As súas rúas, como a do Franco ou a do Vilar, rúas cheas de vida onde conviven estudantes e peregrinos de todas as nacionalidades.

**E a miúdo, envolvéndoo todo, a choiva que en Santiago é tamén unha arte.**
